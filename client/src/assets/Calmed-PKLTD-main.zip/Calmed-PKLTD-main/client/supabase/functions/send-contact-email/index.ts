const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, x-client-info",
}

interface ContactFormData {
  name: string;
  email: string;
  phone?: string;
  message: string;
}

Deno.serve(async (req: Request) => {
  // Handle CORS preflight request
  if (req.method === "OPTIONS") {
    return new Response("ok", {
      status: 200,
      headers: {
        ...corsHeaders,
        "Content-Type": "text/plain",
      },
    });
  }

  try {
    const { name, email, phone, message }: ContactFormData = await req.json();

    // Validate required fields
    if (!name || !email || !message) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return new Response(JSON.stringify({ error: "Invalid email format" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Load Resend API key
    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    if (!resendApiKey) {
      throw new Error("RESEND_API_KEY not configured");
    }

    // Email HTML templates
    const adminEmailHtml = `
      <div style="font-family: Arial, sans-serif; padding: 20px;">
        <h2 style="color:#005595;">New Contact Form Submission from ${name}</h2>
        <p><strong>Name:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        ${phone ? `<p><strong>Phone:</strong> ${phone}</p>` : ""}
        <p><strong>Message:</strong></p>
        <p style="white-space: pre-wrap;">${message}</p>
      </div>
    `;

    const userEmailHtml = `
      <div style="font-family: Arial, sans-serif; padding: 20px;">
        <h2 style="color:#005595;">Thank You for Contacting Us!</h2>
        <p>Hi ${name},</p>
        <p>We’ve received your message and will get back to your query soon.</p>
        <p><strong>Your message:</strong></p>
        <blockquote style="font-style: italic; color: #555;">${message}</blockquote>
        <p>If required please contact us at sonilucky2004@gmail.com</p>
      </div>
    `;

    // Send email to admin
    const adminRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${resendApiKey}`,
      },
      //here the email will be changed to the client email who is handling this website and in the contact form the deployed email id will come 
      body: JSON.stringify({
        from: "Contact Form <onboarding@resend.dev>",
        to: ["sonilucky2004@gmail.com"],
        subject: `New Contact Form Submission from ${name}`,
        html: adminEmailHtml,
      }),
    });

    if (!adminRes.ok) {
      const error = await adminRes.text();
      console.error("Admin email failed:", error);
      throw new Error("Failed to send admin email");
    }

    // Send confirmation email to user
    const userRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${resendApiKey}`,
      },
      body: JSON.stringify({
        from: "Calmed Support <onboarding@resend.dev>",
        to: [email],
        subject: "Thank you for contacting us - We’ll be in touch soon!",
        html: userEmailHtml,
      }),
    });

    if (!userRes.ok) {
      const error = await userRes.text();
      console.error("User email failed:", error);
      // Don't throw — admin email succeeded
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: "Form submitted successfully and emails sent!",
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Function error:", error);
    return new Response(
      JSON.stringify({
        error: "An error occurred while processing your request.",
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
