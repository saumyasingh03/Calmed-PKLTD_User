import React, { useState } from 'react';
import { Send, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import contactBannerImg from '../assets/contactBanner.png';
import hero1 from '../assets/hero1.png';
import { Questions } from '../Options';// const Questions = [




const ContactUs = () => {
  const [openIndex, setOpenIndex] = useState(null);
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', message: '' });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState('idle');
  const [statusMessage, setStatusMessage] = useState('');

  const toggleDropdown = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: undefined }));
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.email.trim()) newErrors.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = 'Please enter a valid email address';
    if (!formData.message.trim()) newErrors.message = 'Message is required';
    else if (formData.message.trim().length < 10) newErrors.message = 'Message must be at least 10 characters long';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);
    setSubmitStatus('idle');

    try {
      const { error } = await supabase.functions.invoke('send-contact-email', {
        body: {
          name: formData.name.trim(),
          email: formData.email.trim(),
          phone: formData.phone.trim() || undefined,
          message: formData.message.trim(),
        },
      });

      if (error) throw error;

      setSubmitStatus('success');
      setStatusMessage("Thank you for your message! We'll get back to you soon.");
      setFormData({ name: '', email: '', phone: '', message: '' });

      setTimeout(() => setSubmitStatus('idle'), 5000);
    } catch (error) {
      console.error('Error submitting form:', error);
      setSubmitStatus('error');
      setStatusMessage('Sorry, there was an error sending your message. Please try again.');
      setTimeout(() => setSubmitStatus('idle'), 5000);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="container mx-auto px-4 sm:px-8">
      {/* Banner Section */}
           <div className="mt-10">
             <div className="relative h-[250px] sm:h-[300px] md:h-[350px] rounded-2xl overflow-hidden shadow-lg">
               <img src={hero1} className="absolute inset-0 w-full h-full object-cover opacity-90" alt="" />
               <div className="absolute inset-0">
                 <div className="absolute inset-0 bg-[linear-gradient(0deg,rgba(0,85,149,0.5),rgba(0,85,149,0.5))] opacity-60 mix-blend-multiply z-10" />
                 <img src={contactBannerImg} className="absolute inset-0 w-full h-full object-cover opacity-90 z-0" alt="" />
               </div>
               <div className="absolute inset-0 flex flex-col gap-4 items-center justify-center px-6 z-10 text-center">
                 <h2 className="text-white text-3xl sm:text-4xl md:text-5xl font-bold">Contact Us</h2>
               </div>
             </div>
           </div>
      {/* form section */}
      <div className="py-10">
        <div className="text-[#005595] text-center sm:text-left flex flex-col gap-4 mb-10">
          <h3 className="text-lg sm:text-xl font-semibold">Get Started</h3>
          <h3 className="font-bold text-3xl sm:text-4xl md:text-6xl">Get in touch with us.</h3>
          <h3 className="font-bold text-3xl sm:text-4xl md:text-6xl">We'd love to hear from you</h3>
        </div>

        {submitStatus === 'success' && (
          <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-3">
            <CheckCircle className="text-green-600 w-5 h-5" />
            <p className="text-green-800">{statusMessage}</p>
          </div>
        )}

        {submitStatus === 'error' && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-3">
            <AlertCircle className="text-red-600 w-5 h-5" />
            <p className="text-red-800">{statusMessage}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-8">
          <div className="flex flex-col md:flex-row md:gap-6 gap-4">
            {['name', 'email', 'phone'].map((field, index) => (
              <div className="w-full" key={index}>
                <input
                  type={field === 'email' ? 'email' : field === 'phone' ? 'tel' : 'text'}
                  name={field}
                  value={formData[field]}
                  onChange={handleInputChange}
                  placeholder={field === 'phone' ? 'Phone Number (Optional)' : field === 'email' ? 'Email Address' : 'Your Name'}
                  className={`bg-[rgba(58,144,202,0.17)] rounded-2xl text-gray-800 px-6 py-3 text-base w-full focus:outline-none focus:ring-2 focus:ring-blue-300 transition-all ${errors[field] ? 'border-2 border-red-500' : ''}`}
                />
                {errors[field] && <p className="text-red-500 text-sm mt-1 ml-2">{errors[field]}</p>}
              </div>
            ))}
          </div>

          <div>
            <textarea
              name="message"
              value={formData.message}
              onChange={handleInputChange}
              rows={6}
              placeholder="Tell us about your project or inquiry..."
              className={`w-full bg-[rgba(58,144,202,0.17)] rounded-2xl px-6 py-4 text-base text-gray-800 resize-none focus:outline-none focus:ring-2 focus:ring-blue-300 transition-all ${errors.message ? 'border-2 border-red-500' : ''}`}
            />
            {errors.message && <p className="text-red-500 text-sm mt-1 ml-2">{errors.message}</p>}
          </div>

          <div className="text-center sm:text-left">
            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex items-center gap-3 text-lg sm:text-xl text-white font-semibold bg-[#056dbc] hover:bg-[#034578] disabled:bg-blue-400 px-8 sm:px-12 py-4 rounded-full transition-all cursor-pointer duration-200 transform hover:scale-105 disabled:scale-100"
            >
              {isSubmitting ? <><Loader2 className="w-5 h-5 animate-spin" /> Sending...</> : <><Send className="w-5 h-5" /> Send Message</>}
            </button>
          </div>
        </form>
      </div>

      <section className="bg-[#e1eff8] px-4 py-12 sm:px-10 mt-10 rounded-2xl">
        <div className="max-w-6xl mx-auto flex flex-col lg:flex-row gap-10">
          <div className="mb-8">
            <h3 className="text-[#005595] font-semibold text-sm">Contact Info</h3>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-[#005595] leading-tight mt-2">
              Have any questions or ideas? <br className="hidden sm:block" /> Feel free to contact us!
            </h2>
          </div>
          <div className="grid sm:grid-cols-2 gap-8">
            <div>
              <h2 className="text-[#005595] font-semibold text-lg mb-2">Email Address</h2>
              <a href="mailto:calmedrotatory@gmail.com" className="text-black text-base hover:underline mb-2 block">
                calmedrotatory@gmail.com
              </a>
              <h2 className="text-[#005595] font-semibold text-lg mb-1 mt-4">Assistance hours:</h2>
              <p className="text-gray-800">Monday - Friday 9 am to 8 pm EST</p>
            </div>
            <div>
              <h2 className="text-[#005595] font-semibold text-lg mb-2">Phone Number</h2>
              <a href="tel:+4401474822294" className="text-black text-base hover:underline mb-4 block">
                +44 (0) 1474 822294
              </a>
              <h2 className="text-[#005595] font-semibold text-lg mb-1">Assistance hours:</h2>
              <p className="text-gray-800">Monday - Friday 9 am to 8 pm EST</p>
            </div>
          </div>
        </div>
      </section>

      <div className="mt-20 px-4 sm:px-8 mb-20">
        <h2 className="text-[#005595] font-bold text-3xl sm:text-4xl mb-8">Frequently Asked Questions</h2>
        <div className="space-y-4">
          {Questions.map((que, idx) => (
            <div key={idx} className="border border-[#005595] rounded-xl shadow-sm hover:shadow-md transition-shadow py-5 px-4">
              <div className="flex justify-between items-center cursor-pointer" onClick={() => toggleDropdown(idx)}>
                <p className="text-base sm:text-lg text-[#024273] font-semibold pr-4">{que.question}</p>
                <button className="text-xl font-semibold text-[#005595] min-w-[24px] h-6 flex items-center justify-center">
                  {openIndex === idx ? '−' : '+'}
                </button>
              </div>
              {openIndex === idx && (
                <div className="mt-4 text-base text-gray-700 px-2 leading-relaxed">{que.answer}</div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ContactUs;
